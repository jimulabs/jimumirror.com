/** Automatically generated file. DO NOT MODIFY */
package com.jimulabs.photo_taker;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}