package com.jimulabs.photo_taker;

import android.app.Activity;
import android.content.Intent;
import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.view.Window;
import android.widget.Button;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.graphics.Bitmap;
import android.util.Log;
import android.widget.Toast;
import android.provider.MediaStore;
import android.net.Uri;
import java.io.File;
import java.io.IOException;
import com.jimulabs.photo_taker.util.StorageHelper;
import com.jimulabs.photo_taker.util.ImageScaler;
import android.graphics.BitmapFactory;

public class ScreenActivity extends Activity {

	private Button mButton;

	private ImageView mPreview;

	public static final int REQUEST_CODE_TAKE_PICTURE = 1345;

	protected static final String LOG_TAG = ScreenActivity.class
			.getSimpleName();

	private static final String EXTRA_PHOTO_PATH_BY_CAMERA = "photoPathByCamera";

	private String mCurrentPhotoPathByCamera;

	@Override
	protected void onCreate(Bundle icicle) {
		super.onCreate(icicle);

		setContentView(R.layout.screen_activity);
		findViews();
		findViews();
		initViews();
		if (icicle != null) {
			mCurrentPhotoPathByCamera = icicle
					.getString(EXTRA_PHOTO_PATH_BY_CAMERA);
		}
	}

	public static void launch(Context context) {
		Intent intent = new Intent(context, ScreenActivity.class);
		context.startActivity(intent);
	}

	private void findViews() {
		mButton = (Button) findViewById(R.id.button);
		mPreview = (ImageView) findViewById(R.id.preview);
	}

	private void initViews() {
		addListeners();
	}

	private void addListeners() {
		mButton.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				takePhoto();
			}
		});
	}

	@Override
	public void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		switch (requestCode) {
		case REQUEST_CODE_TAKE_PICTURE:
			if (resultCode == Activity.RESULT_OK) {
				Bitmap photo = BitmapFactory
						.decodeFile(mCurrentPhotoPathByCamera);
				photo = ImageScaler.scaleBitmapToFitScreenIfTooBig(photo,
						ScreenActivity.this, true);
				String photoPath = mCurrentPhotoPathByCamera;
				mPreview.setImageBitmap(photo);
			}
			break;
		}
	}

	@Override
	protected void onSaveInstanceState(Bundle outState) {
		super.onSaveInstanceState(outState);
		outState.putString(EXTRA_PHOTO_PATH_BY_CAMERA,
				mCurrentPhotoPathByCamera);
	}

	private void takePhoto() {
		Intent takePhotoIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
		try {
			File saveAs = new StorageHelper().createSaveAsFile();
			mCurrentPhotoPathByCamera = saveAs.getAbsolutePath();
			takePhotoIntent.putExtra(MediaStore.EXTRA_OUTPUT,
					Uri.fromFile(saveAs));
			startActivityForResult(takePhotoIntent, REQUEST_CODE_TAKE_PICTURE);
		} catch (IOException e) {
			Log.e(LOG_TAG, "Failed to create picture file", e);
			Toast.makeText(ScreenActivity.this,
					"Cannot create picture file, please try again later.",
					Toast.LENGTH_LONG).show();
		}
	}
}
