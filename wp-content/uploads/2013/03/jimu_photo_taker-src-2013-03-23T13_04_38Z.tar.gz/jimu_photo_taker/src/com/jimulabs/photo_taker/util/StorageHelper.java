package com.jimulabs.photo_taker.util;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import android.annotation.TargetApi;
import android.app.Activity;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;

public class StorageHelper {
	private static final String ALBUM_NAME = "take_photo_from_jimu";
	private String mCurrentPhotoPath;

	public File createSaveAsFile() throws IOException {
		String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss")
				.format(new Date());
		String imageFileName = "JIMU" + timeStamp + "_";
		File image = File.createTempFile(imageFileName, ".jpg", getAlbumDir());
		mCurrentPhotoPath = image.getAbsolutePath();
		return image;
	}

	private File getAlbumDir() {
		File albumDir;
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.FROYO) {
			albumDir = getAlbumDir8Plus();
		} else {
			albumDir = getAlbumDir7Below();
		}
		return albumDir;
	}

	private File getAlbumDir7Below() {
		return new File(Environment.getExternalStorageDirectory() + "Pictures",
				ALBUM_NAME);
	}

	@TargetApi(8)
	private File getAlbumDir8Plus() {
		File storageDir;
		storageDir = new File(
				Environment
						.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES),
				ALBUM_NAME);
		return storageDir;
	}
}
