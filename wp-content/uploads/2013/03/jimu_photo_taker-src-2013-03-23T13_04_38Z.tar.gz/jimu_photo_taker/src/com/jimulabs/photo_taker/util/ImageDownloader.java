package com.jimulabs.photo_taker.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Handler;
import android.os.HandlerThread;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;

public class ImageDownloader {

	private static final String LOG_TAG = ImageDownloader.class.getSimpleName();
	private static final String IMAGES_DIR = "image-cache";
	private static final String DOWNLOAD_THREAD_NAME = "ImageDownloader";

	private static HandlerThread downloadThread;
	private static Handler downloadHandler;

	static {
		downloadThread = new HandlerThread(DOWNLOAD_THREAD_NAME);
		downloadThread.start();
		downloadHandler = new Handler(downloadThread.getLooper());
	}

	public static void loadImage(final ImageView imageView,
			final String imageUrl) {
		loadImage(imageView, imageUrl, null, false);
	}

	public static void loadImage(final ImageView imageView,
			final String imageUrl, final View progressBar,
			final boolean forceDownload) {
		if (TextUtils.isEmpty(imageUrl))
			return;

		if (progressBar != null) {
			progressBar.setVisibility(View.VISIBLE);
		}
		imageView.setTag(imageUrl);
		final Context context = imageView.getContext();
		downloadHandler.post(new Runnable() {
			public void run() {
				final Bitmap bitmap;
				try {
					File imageCacheFile = getImageCacheFile(context, imageUrl);
					if (!forceDownload && imageCacheFile.exists()) {
						bitmap = BitmapFactory
								.decodeStream(new FileInputStream(
										imageCacheFile));
					} else {
						bitmap = downloadImage(context, imageUrl);
					}
					imageView.post(new Runnable() {
						public void run() {
							if (progressBar != null) {
								progressBar.setVisibility(View.GONE);
							}
							if (bitmap != null
									&& imageUrl.equals(imageView.getTag())) {
								imageView.setImageBitmap(bitmap);
							}
						}
					});
				} catch (IOException e) {
					Log.e(LOG_TAG, "Failed to download image: " + imageUrl, e);
				}

			}
		});
	}

	/* Private methods */

	private static Bitmap downloadImage(Context context, String url)
			throws IOException {
		InputStream imageStream = new URL(url).openStream();
		File imageCacheFile = getImageCacheFile(context, url);
		cacheImage(imageStream, imageCacheFile);
		return BitmapFactory.decodeStream(new FileInputStream(imageCacheFile));
	}

	private static File getImageCacheFile(Context context, String url) {
		String fileName = getFileName(url);
		return new File(getCacheDir(context), fileName);
	}

	private static String getFileName(String url) {
		if (url != null && url.trim().length() > 0) {
			return url.replaceAll("\\/|\\:|@|\\?|&|=", "_");
		} else {
			return null;
		}
	}

	private static File getCacheDir(Context context) {
		File baseCacheDir = context.getCacheDir();
		File imageCacheDir = new File(baseCacheDir, IMAGES_DIR);
		if (!imageCacheDir.exists()) {
			imageCacheDir.mkdirs();
		}
		return imageCacheDir;
	}

	private static void cacheImage(InputStream imageStream, File cacheFile)
			throws IOException {
		FileOutputStream writer = null;
		try {
			writer = new FileOutputStream(cacheFile);
			byte[] buffer = new byte[1024];
			int byteCount = 0;
			while ((byteCount = imageStream.read(buffer)) >= 0) {
				writer.write(buffer, 0, byteCount);
			}
			writer.flush();
		} finally {
			if (writer != null) {
				writer.close();
			}
		}
	}

}
