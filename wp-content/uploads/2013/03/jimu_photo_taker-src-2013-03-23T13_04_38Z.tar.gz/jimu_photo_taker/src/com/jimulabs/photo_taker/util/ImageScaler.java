package com.jimulabs.photo_taker.util;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Point;
import android.view.Display;
import android.view.WindowManager;

public class ImageScaler {

	public static Bitmap scaleBitmapToFitScreenIfTooBig(Bitmap image,
			Context context, boolean recycleOrg) {
		Point size = getScreenSize(context);
		int maxWidth = size.x;
		int maxHeight = size.y;
		return scale(image, maxWidth, maxHeight, recycleOrg);
	}

	public static Bitmap scale(Bitmap image, int maxWidth, int maxHeight,
			boolean recycleOrg) {
		Bitmap scaled = image;
		if (image.getWidth() > maxWidth) {
			scaled = Bitmap.createScaledBitmap(image, maxWidth, (int) (maxWidth
					/ (float) image.getWidth() * image.getHeight()), false);
		} else {
			if (image.getHeight() > maxHeight) {
				scaled = Bitmap.createScaledBitmap(image, (int) (maxHeight
						/ (float) image.getHeight() * image.getWidth()),
						maxHeight, false);
			}
		}
		if (recycleOrg && scaled != image)
			image.recycle();
		return scaled;
	}

	private static Point getScreenSize(Context context) {
		WindowManager wm = (WindowManager) context
				.getSystemService(Context.WINDOW_SERVICE);
		Display display = wm.getDefaultDisplay();
		Point size = new Point();
		// display.getSize(size);
		size.x = display.getWidth();
		size.y = display.getHeight();
		return size;
	}

}
