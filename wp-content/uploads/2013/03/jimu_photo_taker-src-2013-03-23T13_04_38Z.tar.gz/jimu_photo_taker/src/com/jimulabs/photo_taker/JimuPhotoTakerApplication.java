package com.jimulabs.photo_taker;

import android.app.Application;

public class JimuPhotoTakerApplication extends Application {

	@Override
	public void onCreate() {
		super.onCreate();
	}
}
