package com.jimulabs.flickr.model;

import android.app.Activity;
import android.content.ContentProvider;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteQueryBuilder;
import android.location.Location;
import android.net.Uri;
import android.text.TextUtils;
import android.util.Log;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

public class WebDataCacheProvider extends ContentProvider {
	public static final String AUTHORITY = "com.jimulabs.flickr.webDataCache";

	private static UriMatcher sUriMatcher;

	protected DatabaseHelper mDBHelper;

	public static final String LOG_TAG = WebDataCacheProvider.class
			.getSimpleName();
	private static final String DATABASE_NAME = "webDataCache.db";
	private static final int DATABASE_VERSION = 1;

	/**
	 * This class helps open, create, and upgrade the database file.
	 */
	static class DatabaseHelper extends SQLiteOpenHelper {
		private Context mContext;

		DatabaseHelper(Context context) {
			super(context, DATABASE_NAME, null, DATABASE_VERSION);
			mContext = context;
		}

		@Override
		public synchronized SQLiteDatabase getReadableDatabase() {
			SQLiteDatabase db;
			try {
				db = super.getReadableDatabase();
			} catch (SQLiteException e) {
				/*
				 * get a writable database and perform upgrade
				 */
				getWritableDatabase().close();
				db = super.getReadableDatabase();
			}
			return db;
		}

		@Override
		public void onCreate(SQLiteDatabase db) {
			db.execSQL(PhotosTable.sqlCreateTable);
			db.execSQL(PlacesTable.sqlCreateTable);
			prepopulate(db);
		}

		private void prepopulate(SQLiteDatabase db) {
			// TODO prepopulate if necessary
		}

		@Override
		public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
			db.execSQL("DROP TABLE IF EXISTS " + PhotosTable.TABLE_NAME);
			db.execSQL("DROP TABLE IF EXISTS " + PlacesTable.TABLE_NAME);
			onCreate(db);
		}
	}

	private static final int PLACES = 1937411214;

	private static final int PHOTOS = 425395053;

	@Override
	public boolean onCreate() {
		mDBHelper = new DatabaseHelper(getContext());
		return true;
	}

	@Override
	public Cursor query(Uri uri, String[] projection, String selection,
			String[] selectionArgs, String sortOrder) {
		SQLiteQueryBuilder qb = new SQLiteQueryBuilder();

		String groupBy = null;
		String orderBy = null;
		final int uriType = sUriMatcher.match(uri);
		switch (uriType) {
			case PLACES:
			qb.setTables(PlacesTable.TABLE_NAME);
			orderBy = TextUtils.isEmpty(sortOrder) ? PlacesTable.DEFAULT_SORT_ORDER
					: sortOrder;
			break;
		case PHOTOS:
			qb.setTables(PhotosTable.TABLE_NAME);
			orderBy = TextUtils.isEmpty(sortOrder) ? PhotosTable.DEFAULT_SORT_ORDER
					: sortOrder;
			break;
		default :
				throw new IllegalArgumentException("Unknown URI " + uri);
		}

		// Get the database and run the query
		SQLiteDatabase db = mDBHelper.getReadableDatabase();
		Cursor c = qb.query(db, projection, selection, selectionArgs, groupBy,
				null, orderBy);

		// Tell the cursor what uri to watch, so it knows when its source data
		// changes
		c.setNotificationUri(getContext().getContentResolver(), uri);
		return c;
	}

	@Override
	public String getType(Uri uri) {
		int uriType = sUriMatcher.match(uri);
		switch (uriType) {
			case PLACES:
			return PlacesTable.CONTENT_TYPE;
		case PHOTOS:
			return PhotosTable.CONTENT_TYPE;
		default :
				throw new IllegalArgumentException("Unknown URI " + uri);
		}
	}

	@Override
	public Uri insert(Uri uri, ContentValues initialValues) {
		SQLiteDatabase db = mDBHelper.getWritableDatabase();
		final int type = sUriMatcher.match(uri);
		String tableName;
		String nullHackColumn = null;
		Uri baseUri;
		switch (type) {
			case PLACES:
			tableName = PlacesTable.TABLE_NAME;
			baseUri = PlacesTable.CONTENT_URI;
			break;
		case PHOTOS:
			tableName = PhotosTable.TABLE_NAME;
			baseUri = PhotosTable.CONTENT_URI;
			break;
		default :
				throw new IllegalArgumentException("Unknown URI " + uri);
		}
		long rowId = db.insert(tableName, nullHackColumn, initialValues);
		if (rowId > 0) {
			uri = ContentUris.withAppendedId(baseUri, rowId);
			if (!db.inTransaction() && isNotificationEnabled())
				getContext().getContentResolver().notifyChange(uri, null);
			return uri;
		}
		throw new SQLException("Failed to insert row into " + uri);
	}

	@Override
	public int bulkInsert(Uri uri, ContentValues[] values) {
		SQLiteDatabase db = mDBHelper.getWritableDatabase();
		int result;
		try {
			db.beginTransaction();
			result = super.bulkInsert(uri, values);
			db.setTransactionSuccessful();
		} finally {
			db.endTransaction();
		}
		getContext().getContentResolver().notifyChange(uri, null);
		return result;
	}

	@Override
	public int delete(Uri uri, String where, String[] whereArgs) {
		SQLiteDatabase db = mDBHelper.getWritableDatabase();
		int count;
		final int type = sUriMatcher.match(uri);
		switch (type) {
			case PLACES:
			count = db.delete(PlacesTable.TABLE_NAME, where, whereArgs);
			break;
		case PHOTOS:
			count = db.delete(PhotosTable.TABLE_NAME, where, whereArgs);
			break;
		default :
				throw new IllegalArgumentException("Unknown URI " + uri);
		}

		if (!db.inTransaction() && isNotificationEnabled())
			getContext().getContentResolver().notifyChange(uri, null);
		return count;
	}

	@Override
	public int update(Uri uri, ContentValues values, String where,
			String[] whereArgs) {
		SQLiteDatabase db = mDBHelper.getWritableDatabase();
		int count;
		final int type = sUriMatcher.match(uri);
		final ContentResolver contentResolver = getContext()
				.getContentResolver();
		switch (type) {
			case PLACES:
			count = db.update(PlacesTable.TABLE_NAME, values, where, whereArgs);
			break;
		case PHOTOS:
			count = db.update(PhotosTable.TABLE_NAME, values, where, whereArgs);
			break;
		default :
				throw new IllegalArgumentException("Unknown URI " + uri);
		}

		if (!db.inTransaction() && isNotificationEnabled())
			contentResolver.notifyChange(uri, null);
		return count;
	}

	static {
		sUriMatcher = new UriMatcher(UriMatcher.NO_MATCH);
		sUriMatcher.addURI(AUTHORITY, "places", PLACES);
		sUriMatcher.addURI(AUTHORITY, "photos", PHOTOS);
	}

	/*
	 * TODO: there should be better way of doing this...
	 */
	private static boolean sNotificationDisabled;

	private static synchronized boolean isNotificationEnabled() {
		return !sNotificationDisabled;
	}

	public static synchronized void disableNotification() {
		sNotificationDisabled = true;
	}

	public static synchronized void enableNotification() {
		sNotificationDisabled = false;
	}

}
