package com.jimulabs.flickr.model;

import android.net.Uri;
import android.provider.BaseColumns;

public class PhotosTable {

	public static final String TABLE_NAME = "photos";

	public static final Uri CONTENT_URI = Uri
			.parse("content://com.jimulabs.flickr.webDataCache/photos");

	public static final String CONTENT_TYPE = "vnd.android.cursor.dir/vnd..photos";

	public static final String CONTENT_ITEM_TYPE = "vnd.android.cursor.item/vnd..photos";

	public static final String DEFAULT_SORT_ORDER = BaseColumns._ID; // TODO change to whatever that makes sense

	public static final String sqlCreateTable = "CREATE TABLE " + TABLE_NAME
			+ " (" + PhotosColumns.ID + " TEXT " + ", " + PhotosColumns.OWNER
			+ " TEXT " + ", " + PhotosColumns.SECRET + " TEXT " + ", "
			+ PhotosColumns.SERVER + " TEXT " + ", " + PhotosColumns.FARM
			+ " INTEGER " + ", " + PhotosColumns.TITLE + " TEXT " + ", "
			+ PhotosColumns.ISPUBLIC + " INTEGER " + ", "
			+ PhotosColumns.ISFRIEND + " INTEGER " + ", "
			+ PhotosColumns.ISFAMILY + " INTEGER " + ", " + PhotosColumns._ID
			+ " INTEGER PRIMARY KEY AUTOINCREMENT " + ");";

	// This class cannot be instantiated
	private PhotosTable() {
	}

	public static final class PhotosColumns implements BaseColumns {

		// This class cannot be instantiated
		private PhotosColumns() {
		}
		public static final String ID = "id";
		public static final String OWNER = "owner";
		public static final String SECRET = "secret";
		public static final String SERVER = "server";
		public static final String FARM = "farm";
		public static final String TITLE = "title";
		public static final String ISPUBLIC = "ispublic";
		public static final String ISFRIEND = "isfriend";
		public static final String ISFAMILY = "isfamily";
		public static final String _ID = "_id";

		public static final String T_ID = TABLE_NAME + "." + ID;
		public static final String T_OWNER = TABLE_NAME + "." + OWNER;
		public static final String T_SECRET = TABLE_NAME + "." + SECRET;
		public static final String T_SERVER = TABLE_NAME + "." + SERVER;
		public static final String T_FARM = TABLE_NAME + "." + FARM;
		public static final String T_TITLE = TABLE_NAME + "." + TITLE;
		public static final String T_ISPUBLIC = TABLE_NAME + "." + ISPUBLIC;
		public static final String T_ISFRIEND = TABLE_NAME + "." + ISFRIEND;
		public static final String T_ISFAMILY = TABLE_NAME + "." + ISFAMILY;
		public static final String T__ID = TABLE_NAME + "." + _ID;

	}

}
