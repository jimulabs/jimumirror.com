package com.jimulabs.flickr;

import android.app.Activity;
import android.content.Intent;
import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.view.Window;
import android.widget.GridView;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.Loader;
import android.support.v4.content.CursorLoader;
import android.database.Cursor;
import com.actionbarsherlock.app.SherlockFragmentActivity;
import com.jimulabs.flickr.model.PhotosTable;
import com.jimulabs.flickr.model.PhotosTable.PhotosColumns;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.view.View;

public class PhotoGridScreenActivity extends SherlockFragmentActivity implements LoaderManager.LoaderCallbacks<Cursor> {

	public static final String EXTRA_PLACE_ID = "EXTRA_PLACE_ID";
	public static final String EXTRA_PLACE_TITLE = "EXTRA_PLACE_TITLE";

	private GridView mPhotoGrid;

	private PhotoGridAdapter mPhotoGridAdapter;

	final static Projection PROJECTION_PHOTO_GRID = new Projection(
			PhotosTable.PhotosColumns.FARM, PhotosTable.PhotosColumns.SERVER,
			PhotosTable.PhotosColumns.ID, PhotosTable.PhotosColumns.SECRET,
			PhotosTable.PhotosColumns.TITLE, PhotosTable.PhotosColumns._ID);
	final static int LOADER_PHOTO_GRID = 812880650;

	@Override
	protected void onCreate(Bundle icicle) {
		super.onCreate(icicle);
		requestWindowFeature(Window.FEATURE_INDETERMINATE_PROGRESS);

		setContentView(R.layout.photo_grid_screen_activity);
		findViews();
		initViews();
		bindData();
		onLaunched();
	}

	public static void launch(Context context, String place_id,
			String place_title) {
		Intent intent = new Intent(context, PhotoGridScreenActivity.class);
		intent.putExtra(PhotoGridScreenActivity.EXTRA_PLACE_ID, place_id);
		intent.putExtra(PhotoGridScreenActivity.EXTRA_PLACE_TITLE, place_title);
		context.startActivity(intent);
	}

	private void findViews() {
		mPhotoGrid = (GridView) findViewById(R.id.photo_grid);
	}

	private void bindData() {
		mPhotoGridAdapter = new PhotoGridAdapter(PhotoGridScreenActivity.this,
				R.layout.photo_grid_item, null);
		mPhotoGrid.setAdapter(mPhotoGridAdapter);
	}

	@Override
	protected void onStart() {
		super.onStart();
		getSupportLoaderManager().initLoader(LOADER_PHOTO_GRID, null, this);
	}

	@Override
	public Loader<Cursor> onCreateLoader(int id, Bundle args) {
		Loader<Cursor> loader = null;
		String[] selectionArgs;
		Context context = PhotoGridScreenActivity.this;
		if (context != null) {
			switch (id) {
			case LOADER_PHOTO_GRID:
				selectionArgs = null;
				loader = new CursorLoader(context, PhotosTable.CONTENT_URI,
						PROJECTION_PHOTO_GRID.columns(), null, selectionArgs,
						null);
				break;
			}
		}
		return loader;
	}

	@Override
	public void onLoadFinished(Loader<Cursor> cursorLoader, Cursor data) {
		switch (cursorLoader.getId()) {
		case LOADER_PHOTO_GRID:
			mPhotoGridAdapter.swapCursor(data);
			break;
		}
	}

	@Override
	public void onLoaderReset(Loader<Cursor> cursorLoader) {
		switch (cursorLoader.getId()) {
		case LOADER_PHOTO_GRID:
			mPhotoGridAdapter.swapCursor(null);
			break;
		}
	}

	private void initViews() {
		addListeners();
	}

	private void addListeners() {
		mPhotoGrid.setOnItemClickListener(new OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long itemId) {
				Cursor c = (Cursor) parent.getItemAtPosition(position);
				String secret = c.getString(c
						.getColumnIndexOrThrow(PhotosTable.PhotosColumns.SECRET));
				String id = c.getString(c
						.getColumnIndexOrThrow(PhotosTable.PhotosColumns.ID));
				String server = c.getString(c
						.getColumnIndexOrThrow(PhotosTable.PhotosColumns.SERVER));
				int farm = c.getInt(c
						.getColumnIndexOrThrow(PhotosTable.PhotosColumns.FARM));
				String photoLarge = String.format(
						"http://farm%s.static.flickr.com/%s/%s_%s_b.jpg", farm,
						server, id, secret);
				String title = c.getString(c
						.getColumnIndexOrThrow(PhotosTable.PhotosColumns.TITLE));
				PhotoViewerActivity.launch(PhotoGridScreenActivity.this,
						photoLarge, title);
			}
		});
	}

	private void onLaunched() {
		DbRefresher.asyncRefreshCacheSearchPhotosByPlaceId(
				PhotoGridScreenActivity.this,
				LOADER_PHOTO_GRID,
				PhotoGridScreenActivity.this,
				getIntent().getStringExtra(
						PhotoGridScreenActivity.EXTRA_PLACE_ID));
		setTitle(getIntent().getStringExtra(
				PhotoGridScreenActivity.EXTRA_PLACE_TITLE));
	}
}
