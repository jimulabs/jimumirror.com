package com.jimulabs.flickr.util;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import com.actionbarsherlock.view.Menu;
import com.actionbarsherlock.view.MenuItem;
import com.jimulabs.flickr.R;

public class ActionBarHelper {

	/**
	 * Use this method as nicer-looking progress bar
	 */
	public static void setRefreshActionRotating(Context context, Menu menu,
			boolean rotating) {
		if (menu != null) {
			MenuItem refreshItem = menu.findItem(R.id.refresh);
			if (rotating && refreshItem.getActionView() == null) {
				LayoutInflater inflater = (LayoutInflater) context
						.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
				ImageView iv = (ImageView) inflater.inflate(
						R.layout.refresh_action_view, null);
				Animation rotation = AnimationUtils.loadAnimation(context,
						R.anim.clockwise_refresh);
				rotation.setRepeatCount(Animation.INFINITE);
				rotation.setInterpolator(context, android.R.interpolator.linear);
				iv.startAnimation(rotation);
				refreshItem.setActionView(iv);
			} else {
				if (refreshItem.getActionView() != null) {
					refreshItem.getActionView().clearAnimation();
					refreshItem.setActionView(null);
				}
			}
		}
	}
}
