package com.jimulabs.flickr;

import android.os.Bundle;
import com.actionbarsherlock.app.SherlockFragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.io.IOException;
import android.widget.ListView;
import android.content.Context;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.Loader;
import android.support.v4.content.CursorLoader;
import android.database.Cursor;
import com.jimulabs.flickr.model.PlacesTable;
import com.jimulabs.flickr.model.PlacesTable.PlacesColumns;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import com.actionbarsherlock.view.Menu;
import com.actionbarsherlock.view.MenuInflater;
import com.actionbarsherlock.view.MenuItem;

public class TopPlacesListFragment extends SherlockFragment implements LoaderManager.LoaderCallbacks<Cursor> {

	private ListView mPlaceList;

	private PlaceListAdapter mPlaceListAdapter;

	final static Projection PROJECTION_PLACE_LIST = new Projection(
			PlacesTable.PlacesColumns.PLACE_ID,
			PlacesTable.PlacesColumns.WOE_NAME,
			PlacesTable.PlacesColumns.PHOTO_COUNT,
			PlacesTable.PlacesColumns._ID);

	final static int LOADER_PLACE_LIST = 549624142;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		return inflater.inflate(R.layout.top_places_list_fragment, container,
				false);
	}

	@Override
	public void onViewCreated(View view, Bundle savedState) {
		super.onViewCreated(view, savedState);
		findViews();
		initViews();
		bindData();
		onLaunched();
	}

	private void findViews() {
		mPlaceList = (ListView) getView().findViewById(R.id.place_list);
	}

	private void bindData() {
		mPlaceListAdapter = new PlaceListAdapter(getSherlockActivity(),
				R.layout.place_list_item, null);
		mPlaceList.setAdapter(mPlaceListAdapter);
	}

	@Override
	public void onStart() {
		super.onStart();
		getLoaderManager().initLoader(LOADER_PLACE_LIST, null, this);
	}

	@Override
	public Loader<Cursor> onCreateLoader(int id, Bundle args) {
		Loader<Cursor> loader = null;
		String[] selectionArgs;
		Context context = getSherlockActivity();
		if (context != null) {
			switch (id) {
			case LOADER_PLACE_LIST:
				selectionArgs = null;
				loader = new CursorLoader(context, PlacesTable.CONTENT_URI,
						PROJECTION_PLACE_LIST.columns(), null, selectionArgs,
						null);
				break;
			}
		}
		return loader;
	}

	@Override
	public void onLoadFinished(Loader<Cursor> cursorLoader, Cursor data) {
		switch (cursorLoader.getId()) {
		case LOADER_PLACE_LIST:
			mPlaceListAdapter.swapCursor(data);
			break;
		}
	}

	@Override
	public void onLoaderReset(Loader<Cursor> cursorLoader) {
		switch (cursorLoader.getId()) {
		case LOADER_PLACE_LIST:
			mPlaceListAdapter.swapCursor(null);
			break;
		}
	}

	private void initViews() {
		addListeners();
	}

	private void addListeners() {
		mPlaceList.setOnItemClickListener(new OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long itemId) {
				Cursor c = (Cursor) parent.getItemAtPosition(position);
				String placeId = c.getString(c
						.getColumnIndexOrThrow(PlacesTable.PlacesColumns.PLACE_ID));
				String woeName = c.getString(c
						.getColumnIndexOrThrow(PlacesTable.PlacesColumns.WOE_NAME));
				String name = String.format("%s", woeName);
				PhotoGridScreenActivity.launch(getSherlockActivity(), placeId,
						name);
			}
		});
	}

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setHasOptionsMenu(true);
	}

	@Override
	public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
		inflater.inflate(R.menu.top_places_list_fragment, menu);
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case R.id.refresh:
			DbRefresher.asyncRefreshCacheGetTopPlaces(getSherlockActivity(),
					LOADER_PLACE_LIST, TopPlacesListFragment.this);
			return true;
		}
		return false;
	}

	private void onLaunched() {
		DbRefresher.asyncRefreshCacheGetTopPlaces(getSherlockActivity(),
				LOADER_PLACE_LIST, TopPlacesListFragment.this);
	}
}
