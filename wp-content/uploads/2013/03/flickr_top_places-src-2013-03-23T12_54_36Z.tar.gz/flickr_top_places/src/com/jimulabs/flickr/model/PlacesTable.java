package com.jimulabs.flickr.model;

import android.net.Uri;
import android.provider.BaseColumns;

public class PlacesTable {

	public static final String TABLE_NAME = "places";

	public static final Uri CONTENT_URI = Uri
			.parse("content://com.jimulabs.flickr.webDataCache/places");

	public static final String CONTENT_TYPE = "vnd.android.cursor.dir/vnd..places";

	public static final String CONTENT_ITEM_TYPE = "vnd.android.cursor.item/vnd..places";

	public static final String DEFAULT_SORT_ORDER = BaseColumns._ID; // TODO change to whatever that makes sense

	public static final String sqlCreateTable = "CREATE TABLE " + TABLE_NAME
			+ " (" + PlacesColumns.PLACE_ID + " TEXT " + ", "
			+ PlacesColumns.WOEID + " TEXT " + ", " + PlacesColumns.LATITUDE
			+ " REAL " + ", " + PlacesColumns.LONGITUDE + " REAL " + ", "
			+ PlacesColumns.PLACE_URL + " TEXT " + ", "
			+ PlacesColumns.PLACE_TYPE + " TEXT " + ", "
			+ PlacesColumns.PLACE_TYPE_ID + " TEXT " + ", "
			+ PlacesColumns.TIMEZONE + " TEXT " + ", " + PlacesColumns._CONTENT
			+ " TEXT " + ", " + PlacesColumns.WOE_NAME + " TEXT " + ", "
			+ PlacesColumns.PHOTO_COUNT + " INTEGER " + ", "
			+ PlacesColumns._ID + " INTEGER PRIMARY KEY AUTOINCREMENT " + ");";

	// This class cannot be instantiated
	private PlacesTable() {
	}

	public static final class PlacesColumns implements BaseColumns {

		// This class cannot be instantiated
		private PlacesColumns() {
		}
		public static final String PLACE_ID = "place_id";
		public static final String WOEID = "woeid";
		public static final String LATITUDE = "latitude";
		public static final String LONGITUDE = "longitude";
		public static final String PLACE_URL = "place_url";
		public static final String PLACE_TYPE = "place_type";
		public static final String PLACE_TYPE_ID = "place_type_id";
		public static final String TIMEZONE = "timezone";
		public static final String _CONTENT = "_content";
		public static final String WOE_NAME = "woe_name";
		public static final String PHOTO_COUNT = "photo_count";
		public static final String _ID = "_id";

		public static final String T_PLACE_ID = TABLE_NAME + "." + PLACE_ID;
		public static final String T_WOEID = TABLE_NAME + "." + WOEID;
		public static final String T_LATITUDE = TABLE_NAME + "." + LATITUDE;
		public static final String T_LONGITUDE = TABLE_NAME + "." + LONGITUDE;
		public static final String T_PLACE_URL = TABLE_NAME + "." + PLACE_URL;
		public static final String T_PLACE_TYPE = TABLE_NAME + "." + PLACE_TYPE;
		public static final String T_PLACE_TYPE_ID = TABLE_NAME + "."
				+ PLACE_TYPE_ID;
		public static final String T_TIMEZONE = TABLE_NAME + "." + TIMEZONE;
		public static final String T__CONTENT = TABLE_NAME + "." + _CONTENT;
		public static final String T_WOE_NAME = TABLE_NAME + "." + WOE_NAME;
		public static final String T_PHOTO_COUNT = TABLE_NAME + "."
				+ PHOTO_COUNT;
		public static final String T__ID = TABLE_NAME + "." + _ID;

	}

}
