package com.jimulabs.flickr;

import android.text.TextUtils;

public class Projection {
	private String[] mCols;
	private String[] mColIds;

	public Projection(String... cols) {
		mCols = cols;
		mColIds = new String[cols.length];
		for (int i = 0; i < cols.length; i++) {
			String col = cols[i];
			int idxOfSpace = col.lastIndexOf(" ");
			mColIds[i] = idxOfSpace >= 0 ? col.substring(idxOfSpace + 1) : col;
		}
	}

	public String[] columns() {
		return mCols;
	}

	public String columnsSql() {
		return TextUtils.join(",", mCols);
	}

	public int index(String col) {
		for (int i = 0; i < mColIds.length; i++)
			if (mColIds[i].equals(col)) {
				return i;
			}
		for (int i = 0; i < mColIds.length; i++)
			if (removeTableName(mColIds[i]).equals(removeTableName(col))) {
				return i;
			}
		return -1;
	}

	private String removeTableName(String col) {
		int idx = col.indexOf('.');
		if (idx < 0) {
			return col;
		} else {
			return col.substring(idx + 1);
		}
	}
}
