package com.jimulabs.flickr;

import android.app.Activity;
import android.content.Intent;
import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.view.Window;
import android.support.v4.view.ViewPager;
import com.actionbarsherlock.app.ActionBar;
import com.actionbarsherlock.app.SherlockFragmentActivity;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.app.FragmentTransaction;
import com.actionbarsherlock.app.ActionBar.TabListener;

public class MainActivity extends SherlockFragmentActivity {

	public class SectionsPagerAdapter extends FragmentPagerAdapter {
		public SectionsPagerAdapter(FragmentManager fm) {
			super(fm);
		}

		@Override
		public Fragment getItem(int i) {
			switch (i) {
			case 0:
				return new TopPlacesListFragment();
			case 1:
				return new TopPlacesMapFragment();
			default:
				throw new IllegalArgumentException("wrong index:" + i);
			}
		}

		@Override
		public int getCount() {
			return TAB_TITLES.length;
		}

		@Override
		public CharSequence getPageTitle(int position) {
			return TAB_TITLES[position];
		}
	}

	/**
	 * The  {@link android.support.v4.view.PagerAdapter}  that will provide fragments for each of the sections. We use a  {@link android.support.v4.app.FragmentPagerAdapter}  derivative, which will keep every loaded fragment in memory. If this becomes too memory intensive, it may be best to switch to a  {@link android.support.v4.app.FragmentStatePagerAdapter} .
	 */
	SectionsPagerAdapter mSectionsPagerAdapter;
	private static final String[] TAB_TITLES = { "List", "Map" };
	private ViewPager mSwipe;

	@Override
	protected void onCreate(Bundle icicle) {
		super.onCreate(icicle);
		requestWindowFeature(Window.FEATURE_INDETERMINATE_PROGRESS);

		setContentView(R.layout.main_activity);
		findViews();
		mSectionsPagerAdapter = new SectionsPagerAdapter(
				getSupportFragmentManager());
		mSwipe.setAdapter(mSectionsPagerAdapter);
		initTabs();
	}

	public static void launch(Context context) {
		Intent intent = new Intent(context, MainActivity.class);
		context.startActivity(intent);
	}

	private void findViews() {
		mSwipe = (ViewPager) findViewById(R.id.swipe);
	}

	private void initTabs() {
		final ActionBar actionBar = getSupportActionBar();
		actionBar.setNavigationMode(ActionBar.NAVIGATION_MODE_TABS);
		mSwipe.setOnPageChangeListener(new ViewPager.SimpleOnPageChangeListener() {
			@Override
			public void onPageSelected(int position) {
				actionBar.setSelectedNavigationItem(position);
			}
		});
		TabListener tabListener = new TabListener() {
			@Override
			public void onTabUnselected(ActionBar.Tab tab,
					FragmentTransaction fragmentTransaction) {
			}

			@Override
			public void onTabSelected(ActionBar.Tab tab,
					FragmentTransaction fragmentTransaction) {
				mSwipe.setCurrentItem(tab.getPosition());
			}

			@Override
			public void onTabReselected(ActionBar.Tab tab,
					FragmentTransaction fragmentTransaction) {
			}
		};
		for (int i = 0; i < mSectionsPagerAdapter.getCount(); i++) {
			actionBar.addTab(actionBar.newTab()
					.setText(mSectionsPagerAdapter.getPageTitle(i))
					.setTabListener(tabListener));
		}
	}
}
