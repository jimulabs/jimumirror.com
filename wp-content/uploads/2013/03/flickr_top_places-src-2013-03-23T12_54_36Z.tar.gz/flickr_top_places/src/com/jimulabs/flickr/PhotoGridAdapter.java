package com.jimulabs.flickr;

import android.content.Context;
import android.database.Cursor;
import android.view.View;
import android.widget.ImageView;
import android.support.v4.widget.ResourceCursorAdapter;
import android.widget.TextView;
import com.jimulabs.flickr.model.PhotosTable;
import com.jimulabs.flickr.model.PhotosTable.PhotosColumns;
import com.jimulabs.flickr.util.ImageDownloader;

public class PhotoGridAdapter extends ResourceCursorAdapter {

	class ViewHolder {
		ImageView photoThumb;
		TextView title;
	}

	private Context mContext;

	public PhotoGridAdapter(Context context, int layout, Cursor c) {
		super(context, layout, c, 0);
		mContext = context;
	}

	public void bindView(View view, Context context, Cursor c) {
		ViewHolder vh = (ViewHolder) view.getTag();
		if (vh == null) {
			vh = new ViewHolder();
			vh.photoThumb = (ImageView) view.findViewById(R.id.photo_thumb);
			vh.title = (TextView) view.findViewById(R.id.title);
			view.setTag(vh);
		}
		String title = c.getString(c
				.getColumnIndexOrThrow(PhotosTable.PhotosColumns.TITLE));
		String secret = c.getString(c
				.getColumnIndexOrThrow(PhotosTable.PhotosColumns.SECRET));
		String id = c.getString(c
				.getColumnIndexOrThrow(PhotosTable.PhotosColumns.ID));
		String server = c.getString(c
				.getColumnIndexOrThrow(PhotosTable.PhotosColumns.SERVER));
		int farm = c.getInt(c
				.getColumnIndexOrThrow(PhotosTable.PhotosColumns.FARM));
		String photoThumb = String.format(
				"http://farm%s.static.flickr.com/%s/%s_%s_t.jpg", farm, server,
				id, secret);
		ImageDownloader.loadImage(vh.photoThumb, photoThumb);
		vh.title.setText(title);
	}

}
