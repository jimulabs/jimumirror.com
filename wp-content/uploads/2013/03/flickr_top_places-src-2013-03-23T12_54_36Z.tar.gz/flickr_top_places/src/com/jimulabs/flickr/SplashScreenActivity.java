package com.jimulabs.flickr;

import android.app.Activity;
import android.content.Intent;
import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.view.Window;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;

public class SplashScreenActivity extends Activity implements AnimationListener {

	private ImageView mImage;
	private Animation mAnimFadein;
	private Animation mAnimFadeout;

	@Override
	protected void onCreate(Bundle icicle) {
		super.onCreate(icicle);
		requestWindowFeature(Window.FEATURE_INDETERMINATE_PROGRESS);

		setContentView(R.layout.splash_screen_activity);
		mImage = (ImageView) findViewById(R.id.image);
		mImage.setImageResource(R.drawable.splash);
		mAnimFadein = AnimationUtils.loadAnimation(this, R.anim.fade_in);
		mAnimFadeout = AnimationUtils.loadAnimation(this, R.anim.fade_out);
		mAnimFadein.setAnimationListener(this);
		mAnimFadeout.setAnimationListener(this);
		int fadeInDuration = getFadeInDuration();
		int fadeOutDuration = getFadeOutDuration();
		if (fadeInDuration >= 0)
			mAnimFadein.setDuration(fadeInDuration);
		if (fadeOutDuration >= 0)
			mAnimFadeout.setDuration(fadeOutDuration);
	}

	public static void launch(Context context) {
		Intent intent = new Intent(context, SplashScreenActivity.class);
		context.startActivity(intent);
	}

	protected int getFadeOutDuration() {
		return -1;
	}

	protected int getFadeInDuration() {
		return -1;
	}

	@Override
	protected void onStart() {
		super.onStart();
		mImage.startAnimation(mAnimFadein);
	}

	public void onAnimationEnd(Animation animation) {
		if (animation == mAnimFadein) {
			mImage.startAnimation(mAnimFadeout);
		} else if (animation == mAnimFadeout) {
			mImage.setVisibility(View.GONE);
			finish();
			onSplashFinish();
		}
	}

	protected void onSplashFinish() {
		MainActivity.launch(SplashScreenActivity.this);
	}

	public void onAnimationRepeat(Animation animation) {
	}

	public void onAnimationStart(Animation animation) {
	}
}
