package com.jimulabs.flickr;

import android.os.Bundle;
import com.actionbarsherlock.app.SherlockFragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.io.IOException;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.GoogleMap;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import android.content.Context;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.Loader;
import android.support.v4.content.CursorLoader;
import android.database.Cursor;
import com.jimulabs.flickr.model.PlacesTable;
import com.jimulabs.flickr.model.PlacesTable.PlacesColumns;
import com.google.android.gms.maps.GoogleMap.OnInfoWindowClickListener;
import com.actionbarsherlock.view.Menu;
import com.actionbarsherlock.view.MenuInflater;
import com.actionbarsherlock.view.MenuItem;

public class TopPlacesMapFragment extends SherlockFragment implements LoaderManager.LoaderCallbacks<Cursor> {

	private class MarkerData {
		String placeId;
		double latitude;
		double longitude;
		String name;
		String title;
		String snippet;
	}

	private MapView mPlacesMapView;

	private List<Marker> mMarkers = new ArrayList<Marker>();

	private Map<String, MarkerData> mMarkerDataMap = new HashMap<String, MarkerData>();

	final static Projection PROJECTION_PLACES_MAP = new Projection(
			PlacesTable.PlacesColumns.PLACE_ID,
			PlacesTable.PlacesColumns.LATITUDE,
			PlacesTable.PlacesColumns.LONGITUDE,
			PlacesTable.PlacesColumns.WOE_NAME,
			PlacesTable.PlacesColumns.PHOTO_COUNT,
			PlacesTable.PlacesColumns._ID);

	final static int LOADER_PLACES_MAP = 1359023184;

	private GoogleMap mPlacesMap;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		return inflater.inflate(R.layout.top_places_map_fragment, container,
				false);
	}

	@Override
	public void onViewCreated(View view, Bundle savedState) {
		super.onViewCreated(view, savedState);
		findViews();
		mPlacesMapView.onCreate(savedState);
		setupMapIfNeeded();
		onLaunched();
	}

	private void findViews() {
		mPlacesMapView = (MapView) getView().findViewById(R.id.places_map);
	}

	private void setupMapIfNeeded() {
		if (mPlacesMap == null) {
			mPlacesMap = mPlacesMapView.getMap();
			if (mPlacesMap != null) {
				setupMap();
			}
		}
	}

	private void setupMap() {
		addMapListeners();
	}

	@Override
	public void onResume() {
		super.onResume();
		mPlacesMapView.onResume();
		setupMapIfNeeded();
	}

	@Override
	public void onPause() {
		mPlacesMapView.onPause();
		super.onPause();
	}

	@Override
	public void onDestroy() {
		mPlacesMapView.onDestroy();
		super.onDestroy();
	}

	@Override
	public void onLowMemory() {
		super.onLowMemory();
		mPlacesMapView.onLowMemory();
	}

	@Override
	public void onSaveInstanceState(Bundle outState) {
		super.onSaveInstanceState(outState);
		mPlacesMapView.onSaveInstanceState(outState);
	}

	private void addMarkers(Cursor c) {
		if (c.getCount() == 0 || c.isAfterLast())
			return;
		removeMarkers();
		while (c.moveToNext()) {
			int photoCount = c
					.getInt(c
							.getColumnIndexOrThrow(PlacesTable.PlacesColumns.PHOTO_COUNT));
			String snippet = String.format("%s photos", photoCount);
			String woeName = c.getString(c
					.getColumnIndexOrThrow(PlacesTable.PlacesColumns.WOE_NAME));
			String name = String.format("%s", woeName);
			String title = String.format("%s", name);
			double longitude = c
					.getDouble(c
							.getColumnIndexOrThrow(PlacesTable.PlacesColumns.LONGITUDE));
			double latitude = c.getDouble(c
					.getColumnIndexOrThrow(PlacesTable.PlacesColumns.LATITUDE));
			String placeId = c.getString(c
					.getColumnIndexOrThrow(PlacesTable.PlacesColumns.PLACE_ID));
			Marker marker = mPlacesMap.addMarker(new MarkerOptions()
					.position(new LatLng(latitude, longitude)).title(title)
					.snippet(snippet));
			mMarkers.add(marker);
			MarkerData mo = new MarkerData();
			mo.placeId = placeId;
			mo.latitude = latitude;
			mo.longitude = longitude;
			mo.name = name;
			mo.title = title;
			mo.snippet = snippet;
			mMarkerDataMap.put(marker.getId(), mo);
		}
	}

	private void removeMarkers() {
		for (Marker m : mMarkers) {
			m.remove();
		}
		mMarkers.clear();
		mMarkerDataMap.clear();
	}

	@Override
	public void onStart() {
		super.onStart();
		getLoaderManager().initLoader(LOADER_PLACES_MAP, null, this);
	}

	@Override
	public Loader<Cursor> onCreateLoader(int id, Bundle args) {
		Loader<Cursor> loader = null;
		String[] selectionArgs;
		Context context = getSherlockActivity();
		if (context != null) {
			switch (id) {
			case LOADER_PLACES_MAP:
				selectionArgs = null;
				loader = new CursorLoader(context, PlacesTable.CONTENT_URI,
						PROJECTION_PLACES_MAP.columns(), null, selectionArgs,
						null);
				break;
			}
		}
		return loader;
	}

	@Override
	public void onLoadFinished(Loader<Cursor> cursorLoader, Cursor data) {
		switch (cursorLoader.getId()) {
		case LOADER_PLACES_MAP:
			addMarkers(data);
			break;
		}
	}

	@Override
	public void onLoaderReset(Loader<Cursor> cursorLoader) {
		switch (cursorLoader.getId()) {
		case LOADER_PLACES_MAP:
			removeMarkers();
			break;
		}
	}

	private void addMapListeners() {
		mPlacesMap
				.setOnInfoWindowClickListener(new OnInfoWindowClickListener() {
					@Override
					public void onInfoWindowClick(Marker marker) {
						String markerId = marker.getId();
						MarkerData md = mMarkerDataMap.get(markerId);
						PhotoGridScreenActivity.launch(getSherlockActivity(),
								md.placeId, md.title);
					}
				});
	}

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setHasOptionsMenu(true);
	}

	@Override
	public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
		inflater.inflate(R.menu.top_places_map_fragment, menu);
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case R.id.refresh:
			DbRefresher.asyncRefreshCacheGetTopPlaces(getSherlockActivity(),
					LOADER_PLACES_MAP, TopPlacesMapFragment.this);
			return true;
		}
		return false;
	}

	private void onLaunched() {
		DbRefresher.asyncRefreshCacheGetTopPlaces(getSherlockActivity(),
				LOADER_PLACES_MAP, TopPlacesMapFragment.this);
	}
}
