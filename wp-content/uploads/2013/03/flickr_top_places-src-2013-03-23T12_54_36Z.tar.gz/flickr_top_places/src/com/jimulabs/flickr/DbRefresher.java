package com.jimulabs.flickr;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.os.AsyncTask;
import android.support.v4.app.LoaderManager.LoaderCallbacks;
import android.util.Log;
import com.actionbarsherlock.app.SherlockFragmentActivity;
import com.jimulabs.flickr.model.PlacesTable;
import com.jimulabs.flickr.model.PlacesTable.PlacesColumns;
import com.jimulabs.flickr.model.PhotosTable;
import com.jimulabs.flickr.model.PhotosTable.PhotosColumns;

public class DbRefresher {
	protected static final String LOG_TAG = DbRefresher.class.getSimpleName();

	private static interface RefreshRunnable {
		void run() throws IOException;
	}
	private static double toDouble(Object object) {
		if (object instanceof String) {
			return Double.parseDouble((String) object);
		} else {
			return (Double) object;
		}
	}

	private static int toInt(Object object) {
		if (object instanceof String) {
			return Integer.parseInt((String) object);
		} else {
			return (Integer) object;
		}
	}

	private static String toString(Object object) {
		if (object != null) {
			return object.toString();
		} else {
			return "null";
		}
	}
	private static void asyncRefresh(final SherlockFragmentActivity activity,
			final int loaderId,
			final LoaderCallbacks<? extends Cursor> loaderCallbacks,
			final RefreshRunnable refreshRunnable) {
		if (activity.isFinishing()) {
			return;
		}
		activity.setSupportProgressBarIndeterminateVisibility(true);
		new AsyncTask<Void, Void, Boolean>() {
			@Override
			protected Boolean doInBackground(Void... params) {
				try {
					refreshRunnable.run();
					return true;
				} catch (IOException e) {
					Log.e(LOG_TAG, "Failed to refresh cache", e);
				}
				return false;
			}

			protected void onPostExecute(Boolean success) {
				if (success) {
					activity.getSupportLoaderManager().restartLoader(loaderId,
							null, loaderCallbacks);
				}
				activity.setSupportProgressBarIndeterminateVisibility(false);
			};
		}.execute();
	}

	public static void refreshCacheGetTopPlaces(Context context)
			throws IOException {
		List<Map<String, Object>> places = ServerApi.getTopPlaces(context);
		ContentResolver contentResolver = context.getContentResolver();
		contentResolver.delete(PlacesTable.CONTENT_URI, null, null);
		ContentValues[] values = new ContentValues[places.size()];
		for (int i = 0; i < values.length; i++) {
			Map<String, Object> item = places.get(i);
			ContentValues value = new ContentValues();
			values[i] = value;
			value.put(PlacesColumns.PLACE_ID, toString(item.get("place_id")));
			value.put(PlacesColumns.WOEID, toString(item.get("woeid")));
			value.put(PlacesColumns.LATITUDE, toDouble(item.get("latitude")));
			value.put(PlacesColumns.LONGITUDE, toDouble(item.get("longitude")));
			value.put(PlacesColumns.PLACE_URL, toString(item.get("place_url")));
			value.put(PlacesColumns.PLACE_TYPE,
					toString(item.get("place_type")));
			value.put(PlacesColumns.PLACE_TYPE_ID,
					toString(item.get("place_type_id")));
			value.put(PlacesColumns.TIMEZONE, toString(item.get("timezone")));
			value.put(PlacesColumns._CONTENT, toString(item.get("_content")));
			value.put(PlacesColumns.WOE_NAME, toString(item.get("woe_name")));
			value.put(PlacesColumns.PHOTO_COUNT, toInt(item.get("photo_count")));
		}
		contentResolver.bulkInsert(PlacesTable.CONTENT_URI, values);
	}

	public static void asyncRefreshCacheGetTopPlaces(
			final SherlockFragmentActivity activity, final int loaderId,
			final LoaderCallbacks<? extends Cursor> loaderCallbacks) {
		asyncRefresh(activity, loaderId, loaderCallbacks,
				new RefreshRunnable() {
					@Override
					public void run() throws IOException {
						DbRefresher.refreshCacheGetTopPlaces(activity);
					}
				});
	}

	public static void refreshCacheSearchPhotosByPlaceId(Context context,
			final String placeId) throws IOException {
		List<Map<String, Object>> photos = ServerApi.searchPhotosByPlaceId(
				context, placeId);
		ContentResolver contentResolver = context.getContentResolver();
		contentResolver.delete(PhotosTable.CONTENT_URI, null, null);
		ContentValues[] values = new ContentValues[photos.size()];
		for (int i = 0; i < values.length; i++) {
			Map<String, Object> item = photos.get(i);
			ContentValues value = new ContentValues();
			values[i] = value;
			value.put(PhotosColumns.ID, toString(item.get("id")));
			value.put(PhotosColumns.OWNER, toString(item.get("owner")));
			value.put(PhotosColumns.SECRET, toString(item.get("secret")));
			value.put(PhotosColumns.SERVER, toString(item.get("server")));
			value.put(PhotosColumns.FARM, toInt(item.get("farm")));
			value.put(PhotosColumns.TITLE, toString(item.get("title")));
			value.put(PhotosColumns.ISPUBLIC, toInt(item.get("ispublic")));
			value.put(PhotosColumns.ISFRIEND, toInt(item.get("isfriend")));
			value.put(PhotosColumns.ISFAMILY, toInt(item.get("isfamily")));
		}
		contentResolver.bulkInsert(PhotosTable.CONTENT_URI, values);
	}

	public static void asyncRefreshCacheSearchPhotosByPlaceId(
			final SherlockFragmentActivity activity, final int loaderId,
			final LoaderCallbacks<? extends Cursor> loaderCallbacks,
			final String placeId) {
		asyncRefresh(activity, loaderId, loaderCallbacks,
				new RefreshRunnable() {
					@Override
					public void run() throws IOException {
						DbRefresher.refreshCacheSearchPhotosByPlaceId(activity,
								placeId);
					}
				});
	}
}
