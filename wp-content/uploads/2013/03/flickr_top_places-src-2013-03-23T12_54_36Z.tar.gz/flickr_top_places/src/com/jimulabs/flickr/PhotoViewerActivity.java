package com.jimulabs.flickr;

import android.app.Activity;
import android.content.Intent;
import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.view.Window;
import android.widget.TextView;
import android.webkit.WebView;
import android.view.View;
import android.webkit.WebViewClient;
import android.graphics.Bitmap;

public class PhotoViewerActivity extends Activity {

	public static final String EXTRA_PHOTO_URL = "EXTRA_PHOTO_URL";
	public static final String EXTRA_TITLE = "EXTRA_TITLE";

	private TextView mText;

	private WebView mWebView;

	@Override
	protected void onCreate(Bundle icicle) {
		super.onCreate(icicle);
		requestWindowFeature(Window.FEATURE_INDETERMINATE_PROGRESS);

		setContentView(R.layout.photo_viewer_activity);
		findViews();
		initViews();
		findViews();
		onLaunched();
	}

	public static void launch(Context context, String photo_url, String title) {
		Intent intent = new Intent(context, PhotoViewerActivity.class);
		intent.putExtra(PhotoViewerActivity.EXTRA_PHOTO_URL, photo_url);
		intent.putExtra(PhotoViewerActivity.EXTRA_TITLE, title);
		context.startActivity(intent);
	}

	private void findViews() {
		mText = (TextView) findViewById(R.id.text);
		mWebView = (WebView) findViewById(R.id.web_view);
	}

	private void initViews() {
		mWebView.getSettings().setSupportZoom(true);
		mWebView.getSettings().setBuiltInZoomControls(true);
		mWebView.getSettings().setLoadWithOverviewMode(true);
		mWebView.getSettings().setUseWideViewPort(true);
		final View progressWebView = findViewById(R.id.progress_web_view);
		mWebView.setWebViewClient(new WebViewClient() {
			@Override
			public void onPageStarted(WebView view, String url, Bitmap favicon) {
				progressWebView.setVisibility(View.VISIBLE);
				super.onPageStarted(view, url, favicon);
			}

			@Override
			public void onPageFinished(WebView view, String url) {
				progressWebView.setVisibility(View.GONE);
				super.onPageFinished(view, url);
			}
		});
	}

	private void onLaunched() {
		mText.setText(getIntent().getStringExtra(
				PhotoViewerActivity.EXTRA_TITLE));
		mWebView.loadUrl(getIntent().getStringExtra(
				PhotoViewerActivity.EXTRA_PHOTO_URL));
	}
}
