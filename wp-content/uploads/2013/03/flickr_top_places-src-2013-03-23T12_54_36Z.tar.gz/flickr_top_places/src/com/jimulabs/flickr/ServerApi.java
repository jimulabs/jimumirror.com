package com.jimulabs.flickr;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.net.URLEncoder;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpResponseException;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.params.HttpParams;

import com.jayway.jsonpath.JsonPath;

import android.content.Context;
import android.net.http.AndroidHttpClient;

public class ServerApi {

	private static final String USER_AGENT = "android";

	public enum HttpMethod {
		GET, POST, PUT, DELETE
	}

	private static InputStream execute(AndroidHttpClient client, String url,
			HttpMethod method, HashMap<String, String> params)
			throws IOException, HttpResponseException {
		HttpUriRequest request = createRequest(url, method, params);
		HttpResponse response = client.execute(request);
		int statusCode = response.getStatusLine().getStatusCode();
		switch (statusCode) {
			case HttpURLConnection.HTTP_OK :
			case HttpURLConnection.HTTP_ACCEPTED :
			case HttpURLConnection.HTTP_CREATED :
				return response.getEntity().getContent();
			default :
				throw new HttpResponseException(statusCode, url);
		}
	}

	private static HttpUriRequest createRequest(String uri, HttpMethod method,
			HashMap<String, String> params) {
		HttpUriRequest request;
		switch (method) {
			case GET :
				request = new HttpGet(uri);
				break;
			case POST :
				request = new HttpPost(uri);
				break;
			case PUT :
				request = new HttpPut(uri);
				break;
			case DELETE :
				request = new HttpDelete(uri);
				break;
			default :
				throw new UnsupportedOperationException("unsupported method:"
						+ method);
		}
		if (params != null) {
			HttpParams httpParams = request.getParams();
			for (String pname : params.keySet())
				httpParams.setParameter(pname, params.get(pname));
		}
		return request;
	}

	private static final Pattern PATTERN = Pattern.compile(
			"^\\s*\\w+\\((.+)\\)\\s*;?\\s*$", Pattern.CASE_INSENSITIVE);

	private static String toJsonString(InputStream input) throws IOException {
		String s = is2s(input);
		Matcher m = PATTERN.matcher(s);
		if (m.matches())
			return m.group(1);
		else
			return s;
	}

	public static String is2s(InputStream is) throws IOException {
		BufferedReader reader = new BufferedReader(new InputStreamReader(is));
		StringBuilder sb = new StringBuilder();
		String line;
		while ((line = reader.readLine()) != null)
			sb.append(line).append("\n");
		return sb.toString();
	}

	public static List<Map<String, Object>> getTopPlaces(Context context)
			throws IOException {
		String url = "http://api.flickr.com/services/rest/?method=flickr.places.getTopPlacesList&api_key=ead1a52dcfb8bfe0a073dfe96b1fca9b&place_type_id=22&format=json";
		HashMap<String, String> params = null;
		AndroidHttpClient client = AndroidHttpClient.newInstance(USER_AGENT,
				context);
		try {
			InputStream input = execute(client, url, HttpMethod.GET, params);
			String jsonString = toJsonString(input);
			String jsonPath = "$.places.place";
			return JsonPath.read(jsonString, jsonPath);
		} finally {
			client.close();
		}
	}

	public static List<Map<String, Object>> searchPhotosByPlaceId(
			Context context, final String placeId) throws IOException {
		String url = String
				.format("http://api.flickr.com/services/rest/?method=flickr.photos.search&api_key=ead1a52dcfb8bfe0a073dfe96b1fca9b&format=json&place_id=%s",
						URLEncoder.encode(placeId, "utf8"));
		HashMap<String, String> params = null;
		AndroidHttpClient client = AndroidHttpClient.newInstance(USER_AGENT,
				context);
		try {
			InputStream input = execute(client, url, HttpMethod.GET, params);
			String jsonString = toJsonString(input);
			String jsonPath = "$.photos.photo";
			return JsonPath.read(jsonString, jsonPath);
		} finally {
			client.close();
		}
	}

}
