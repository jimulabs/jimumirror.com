package com.jimulabs.flickr;

import android.content.Context;
import android.database.Cursor;
import android.view.View;
import android.widget.ImageView;
import android.support.v4.widget.ResourceCursorAdapter;
import android.widget.TextView;
import com.jimulabs.flickr.model.PlacesTable;
import com.jimulabs.flickr.model.PlacesTable.PlacesColumns;
import com.jimulabs.flickr.util.ImageDownloader;

public class PlaceListAdapter extends ResourceCursorAdapter {

	class ViewHolder {
		TextView name;
		TextView photos;
	}

	private Context mContext;

	public PlaceListAdapter(Context context, int layout, Cursor c) {
		super(context, layout, c, 0);
		mContext = context;
	}

	public void bindView(View view, Context context, Cursor c) {
		ViewHolder vh = (ViewHolder) view.getTag();
		if (vh == null) {
			vh = new ViewHolder();
			vh.name = (TextView) view.findViewById(R.id.name);
			vh.photos = (TextView) view.findViewById(R.id.photos);
			view.setTag(vh);
		}
		int photoCount = c.getInt(c
				.getColumnIndexOrThrow(PlacesTable.PlacesColumns.PHOTO_COUNT));
		String photos = String.format("%s photos", photoCount);
		String woeName = c.getString(c
				.getColumnIndexOrThrow(PlacesTable.PlacesColumns.WOE_NAME));
		String name = String.format("%s", woeName);
		vh.name.setText(name);
		vh.photos.setText(photos);
	}

}
