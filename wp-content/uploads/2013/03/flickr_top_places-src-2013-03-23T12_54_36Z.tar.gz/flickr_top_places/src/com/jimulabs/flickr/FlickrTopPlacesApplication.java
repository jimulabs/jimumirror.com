package com.jimulabs.flickr;

import android.app.Application;

public class FlickrTopPlacesApplication extends Application {

	@Override
	public void onCreate() {
		super.onCreate();
	}
}
